# File Management System

## Overview

The system uses two separate directories for file management:

- `data/` - User's working files (history storage)
- `seeds/` - Template/sample files for quick setup

## File Path Security

### Automatic Sanitization

All user input for filenames is automatically sanitized to prevent security issues:

1. **Directory Traversal Prevention**

   - Removes `../` and `./` patterns
   - Blocks path separators (`/` and `\`)
   - Prevents access to parent directories

2. **Extension Handling**

   - User enters filename WITHOUT extension
   - System automatically appends `.csv`
   - Any existing extensions are stripped

3. **Character Filtering**
   - Removes dangerous characters: `: * ? " < > |`
   - Trims whitespace
   - Ensures clean, safe filenames

### Examples

**User Input** → **Actual Path**

- `red` → `data/red.csv`
- `../secret` → `data/secret.csv`
- `folder/file` → `data/folderfile.csv`
- `network.txt` → `data/network.csv`
- `my network` → `data/my network.csv`

## Load Network Behavior

### Previous Behavior (Issue)

- Loading a file would ADD nodes to existing network
- Manual additions would persist after loading
- Could create duplicate or mixed data

### Current Behavior (Fixed)

- Loading a file CLEARS the entire network first
- Ensures loaded data matches file exactly
- Prevents data corruption from mixed sources

## Save Network Behavior

### Validation

- Cannot save empty network
- Prompts user for filename (without extension)
- Saves to `data/` directory automatically
- Preserves exact weights from user input

### File Format

```csv
# NODES
N;0;UAA
N;1;Plaza_Patria

# EDGES
E;0;1;3.5
```

## Seed File Generation

### Purpose

- Create sample networks for testing
- Provide templates for new users
- Separate from working data

### Usage

1. Go to: Road Network Management → Generate Seed File
2. Enter filename (e.g., `aguascalientes`)
3. File created at: `seeds/aguascalientes.csv`
4. Load it using: Load Network → `aguascalientes`

### Default Seed Content

- 6 nodes (UAA, Plaza Patria, Centro Historico, etc.)
- 9 edges with realistic weights
- Ready to use for testing algorithms

## Directory Structure

```
project/
├── data/           # User working files (git-ignored recommended)
│   ├── red.csv
│   ├── network1.csv
│   └── backup.csv
├── seeds/          # Template files (can be committed to git)
│   ├── aguascalientes.csv
│   └── sample.csv
└── docs/
    └── file-management.md
```

## Best Practices

1. **Use Seeds for Templates**

   - Generate seed files for common scenarios
   - Share seeds with team members
   - Keep seeds in version control

2. **Use Data for Work**

   - Save your working networks to data/
   - Add data/ to .gitignore
   - Backup important networks regularly

3. **Filename Conventions**

   - Use descriptive names: `city_center`, `highway_network`
   - Avoid special characters
   - No need to add `.csv` extension

4. **Loading Files**
   - Always verify node count after loading
   - Check adjacency list to confirm correct data
   - Remember: loading REPLACES current network

## Security Notes

- All file operations are restricted to project directories
- Cannot access system files or parent directories
- Input validation prevents path injection attacks
- File extensions are enforced (CSV only)
