# Urban Traffic Simulation System - Project Overview

## 📌 Executive Summary

Console-based urban traffic simulator that models intersections as graph nodes and streets as weighted edges. The system manages road networks, calculates optimal routes, analyzes connectivity, and registers vehicles using hash tables for fast operations.

**Course:** Data Structures II
**Institution:** Universidad Autónoma de Aguascalientes
**Delivery Date:** December 9, 2025
**Team Size:** 3-4 members

---

## 🎯 Project Objectives

### Primary Goals
1. Build a functional road network using custom graph implementation
2. Calculate shortest paths between intersections (Dijkstra algorithm)
3. Analyze network connectivity (BFS/DFS traversals)
4. Manage vehicles efficiently using custom hash table
5. Provide file-based persistence (CSV format)

### Learning Outcomes
- Master graph data structures and algorithms
- Implement hash tables with collision resolution
- Apply algorithmic complexity analysis
- Develop modular, maintainable C++ code
- Practice software documentation standards

---

## 🏗️ System Architecture

### Core Components

**1. Graph Module (Road Network)**
- Nodes: Intersections with ID and name
- Edges: Streets with weights (distance/time)
- Representation: Adjacency list (primary) + adjacency matrix (visualization)
- Operations: Insert, delete, display, traverse

**2. Algorithm Module (Route Analysis)**
- Dijkstra: Shortest path calculation
- BFS: Breadth-first traversal for connectivity
- DFS: Depth-first search for component detection
- Connected components counter

**3. Hash Table Module (Vehicle Registry)**
- Fast lookup by vehicle ID
- Custom hash function (modular or multiplicative)
- Collision resolution (open addressing or chaining)
- CRUD operations: Insert, search, delete

**4. File I/O Module (Persistence)**
- Load network from CSV files
- Save modified network
- Format validation and error handling

**5. User Interface (Console)**
- Interactive menu system
- Input validation
- Formatted output (tables, ASCII diagrams)
- Error messages and confirmations

---

## 📊 Functional Scope

### What the System DOES

✅ **Network Management**
- Load/save road networks from/to CSV files
- Add/remove intersections (nodes)
- Add/remove streets (weighted edges)
- Display network as adjacency list or matrix

✅ **Route Calculation**
- Find shortest path between two points
- Report total distance and path sequence
- Measure computation time

✅ **Connectivity Analysis**
- Explore reachable nodes from origin (BFS/DFS)
- Count connected components in network
- Identify bottlenecks (high-degree nodes)

✅ **Vehicle Management**
- Register vehicles with ID, plate, origin, destination
- Fast search by vehicle ID
- Remove vehicles from registry
- Display hash table statistics (load factor, size)

✅ **Required Test Cases**
- C1: Calculate route from UAA to Glorieta Norte
- C2: Show connected components after removing specific edge

### What the System DOES NOT DO

❌ Real-time traffic simulation
❌ Graphical user interface (GUI)
❌ GPS coordinates or map rendering
❌ Multi-threading or parallel processing
❌ Network flow optimization
❌ External library dependencies (except basic STL)

---

## 🛠️ Technical Stack

### Programming Language
**C++ (Standard: C++11 or higher)**
- Justification: Course requirement, performance, memory control
- Allowed STL: `string`, `iostream`, `fstream`, `iomanip`, `cmath`, `ctime`
- Forbidden: `unordered_map`, `vector`, external graph libraries

### Data Structures (Custom Implementation Required)

**Graph**
```
Implementation: Adjacency list with linked lists
Node storage: Static array (max 50 nodes)
Edge storage: Dynamic linked lists
Memory: O(V + E) where V=nodes, E=edges
```

**Hash Table**
```
Implementation: Open addressing or chaining
Size: Prime number (e.g., 101)
Hash function: h(key) = key % size (or multiplicative)
Collision resolution: Linear probing or separate chaining
Load factor: α = n/m (monitored, not enforced)
```

### Algorithms Complexity

| Algorithm | Time Complexity | Space Complexity |
|-----------|----------------|------------------|
| BFS | O(V + E) | O(V) |
| DFS | O(V + E) | O(V) |
| Dijkstra | O(V²) or O((V+E)logV)* | O(V) |
| Hash Insert | O(1) average | O(n) |
| Hash Search | O(1) average | O(1) |
| Hash Delete | O(1) average | O(1) |

*Depends on priority queue implementation (array vs binary heap)

### File Formats

**Network File (red.csv)**
```csv
# NODES
N;0;UAA
N;1;Plaza_Patria
N;2;Centro_Historico

# EDGES (directed)
E;0;1;3.5
E;1;2;2.8
E;0;2;6.2
```

**Vehicle File (vehiculos.csv)**
```csv
# VEHICLES
V;ABC123;Sedan;ABC-123-X;0;2;08:30
V;XYZ999;Truck;XYZ-999-Y;1;0;09:15
```

### Development Tools

**Compiler:** g++ or clang++
**Build System:** Makefile or manual compilation
**Version Control:** Git (minimum 4 commits required)
**Text Editor:** Any (VS Code, Vim, CLion, Code::Blocks)
**Debugger:** gdb or IDE integrated debugger
**Documentation:** LaTeX or Word (IEEE format)

---

## 📋 Deliverables Checklist

### Code Deliverables
- [ ] Source code files (.h and .cpp)
- [ ] Makefile or compilation instructions
- [ ] Sample CSV files (red.csv, vehiculos.csv)
- [ ] README.md with usage instructions
- [ ] GitHub repository (public or private with access)

### Documentation Deliverables
- [ ] PDF report in IEEE format
- [ ] Design section: data structures diagrams
- [ ] Implementation section: algorithm explanations
- [ ] Testing section: console screenshots
- [ ] Results section: mandatory test cases C1 and C2
- [ ] Conclusions and future work
- [ ] Team member contribution rubric

### Demonstration Requirements
- [ ] Live demo on December 10-11, 2025
- [ ] Show all menu options working
- [ ] Execute mandatory test cases
- [ ] Handle edge cases (invalid input, nonexistent nodes)
- [ ] Answer professor's technical questions

---

## 🎯 Evaluation Criteria (100 points)

| Criterion | Points | Description |
|-----------|--------|-------------|
| **Custom Structures** | 25 | Graph and hash table implemented without external libraries |
| **Algorithms Correctness** | 25 | BFS/DFS/Dijkstra work correctly on edge cases |
| **Hash Operations** | 20 | Insert/search/delete function properly |
| **File I/O + Menus** | 15 | CSV parsing works, menu navigation is intuitive |
| **Code Quality** | 10 | Clean, modular, well-commented code |
| **Report Quality** | 5 | Clear documentation with evidence |
| **TOTAL** | **100** | |

### Grading Notes
- Compilation errors: -20 points
- Segmentation faults: -15 points
- Missing mandatory test cases: -10 points each
- Late submission: -10 points per day
- Plagiarism: 0 points + academic consequences

---

## 🚀 Success Metrics

### Minimum Viable Product (70 points)
- Graph with 10+ nodes loaded from file
- BFS/DFS work on connected graph
- Dijkstra finds shortest path
- Hash table stores 5+ vehicles
- Menu navigates without crashes

### Full Credit Product (90 points)
- All above + proper error handling
- Both mandatory test cases work
- Code is modular and documented
- Report includes all required sections

### Exceptional Product (100 points)
- All above + edge case handling
- Optimized Dijkstra with binary heap
- ASCII map visualization
- Professional-grade documentation
- Clean Git history with meaningful commits

---

## ⚠️ Common Pitfalls to Avoid

1. **Using STL containers for core structures** (unordered_map, vector for adjacency list)
2. **Not handling file I/O errors** (missing file, wrong format)
3. **Memory leaks** in linked list implementations
4. **Dijkstra failing on disconnected graphs**
5. **Hash table not handling collisions**
6. **Poor menu navigation** (no way to go back, crashes on invalid input)
7. **Missing validation** (adding edge to nonexistent nodes)
8. **Late start** (starting 2 days before deadline)

---

## 📅 Recommended Timeline

### Week 1 (November 25 - December 1)
- Day 1-2: Menu system + Graph structure
- Day 3-4: Graph CRUD + File I/O
- Day 5-7: BFS/DFS implementation

### Week 2 (December 2 - December 8)
- Day 1-2: Dijkstra algorithm
- Day 3-4: Hash table implementation
- Day 5-6: Test cases + bug fixing
- Day 7: Documentation + report

### Week 3 (December 9 - December 11)
- December 9: Submission
- December 10-11: In-person reviews

---

## 🔗 External Resources

### Algorithm References
- Dijkstra's algorithm: Cormen et al., "Introduction to Algorithms"
- Graph traversals: GeeksforGeeks, Visualgo
- Hash tables: Hash table visualization tools

### Coding Standards
- Google C++ Style Guide
- C++ Core Guidelines

### Documentation
- IEEE paper template
- Markdown syntax guide
- Git best practices

---

## 📞 Support Channels

**Professor Office Hours:** TBD
**Course Forum:** TBD
**Team Communication:** WhatsApp/Discord/Slack
**Version Control:** GitHub (recommended)

---

## 🎓 Academic Integrity

- Code must be original team work
- Algorithm pseudocode from textbooks is acceptable
- Cite any external references used
- Collaboration between teams is forbidden
- AI assistance (ChatGPT, Copilot) allowed for debugging, not for complete implementations

---

## ✅ Final Checklist Before Submission

- [ ] Code compiles without warnings
- [ ] All menu options work
- [ ] Both test cases execute successfully
- [ ] No memory leaks (run valgrind if available)
- [ ] CSV files load correctly
- [ ] README explains how to run program
- [ ] Report has all required sections
- [ ] GitHub has 4+ commits with good messages
- [ ] Team member rubric is filled
- [ ] Files are named correctly (apellido_proyecto.zip)